"""
traffic_analysis.py
Turns raw per-frame detections into traffic-management intelligence:
lane assignment, density/congestion classification, and running
statistics across the whole video (totals, peaks, averages, class
distribution, per-frame trend for the chart).
"""
import cv2
import numpy as np

import config


def classify_density(vehicle_count):
    """Map a vehicle count to a LOW/MODERATE/HIGH/SEVERE label using the
    configurable thresholds in config.DENSITY_THRESHOLDS."""
    for label, (low, high) in config.DENSITY_THRESHOLDS.items():
        if low <= vehicle_count <= high:
            return label
    return "SEVERE"


def signal_for_density(density_label):
    """Map a traffic-density label to a recommended signal color for
    that lane.

    LOW traffic -> RED (this lane doesn't need to be serviced right now).
    MODERATE / HIGH / SEVERE -> GREEN (this lane has traffic that needs
    to be cleared, so it gets priority).
    """
    return "RED" if density_label == "LOW" else "GREEN"


def build_lane_signal(avg_vehicles):
    """Turn one lane's average vehicle count into a full signal
    decision: density label, RED/GREEN recommendation, and a suggested
    green-light duration when the signal is GREEN. Shared by both the
    per-frame running signal (live camera + video overlay, based on the
    average so far) and the final whole-video signal (based on the
    average across every frame) - same rule, same shape, everywhere."""
    avg_vehicles = round(avg_vehicles, 2)
    density = classify_density(round(avg_vehicles))
    signal = signal_for_density(density)
    return {
        "avg_vehicles": avg_vehicles,
        "density": density,
        "signal": signal,
        "suggested_green_seconds": (
            config.SIGNAL_GREEN_DURATION_SECONDS.get(density, 0) if signal == "GREEN" else 0
        ),
    }


def build_lane_polygons(frame_w, frame_h):
    """Scale the fractional lane polygons from config to actual pixel
    coordinates for this video's resolution."""
    scaled = {}
    for lane_name, points in config.LANE_POLYGONS.items():
        scaled[lane_name] = np.array(
            [(int(x * frame_w), int(y * frame_h)) for x, y in points],
            dtype=np.int32,
        )
    return scaled


def assign_lane(bbox, lane_polygons):
    """Assign a detection to a lane based on whether its bbox center
    falls inside that lane's polygon. Returns None if it falls outside
    every configured lane."""
    x1, y1, x2, y2 = bbox
    center = (float((x1 + x2) / 2), float((y1 + y2) / 2))
    for lane_name, polygon in lane_polygons.items():
        if cv2.pointPolygonTest(polygon, center, False) >= 0:
            return lane_name
    return None


class TrafficStatsTracker:
    """Accumulates traffic statistics across every processed frame."""

    def __init__(self, lane_polygons):
        self.lane_polygons = lane_polygons
        self.lane_names = list(lane_polygons.keys())

        self.frame_count = 0
        self.total_detections = 0
        self.max_vehicles_in_frame = 0
        self.sum_vehicles_per_frame = 0

        self.class_totals = {name: 0 for name in config.VEHICLE_CLASSES}
        self.lane_totals = {lane: 0 for lane in self.lane_names}

        # per-frame trend, sampled down later for the chart
        self.frame_trend = []          # list of (frame_index, vehicle_count)

    def update(self, detections, frame_index):
        self.frame_count += 1
        vehicle_count = len(detections)
        self.total_detections += vehicle_count
        self.sum_vehicles_per_frame += vehicle_count
        self.max_vehicles_in_frame = max(self.max_vehicles_in_frame, vehicle_count)

        lane_counts = {lane: 0 for lane in self.lane_names}

        for det in detections:
            cls_name = det["class_name"]
            self.class_totals[cls_name] = self.class_totals.get(cls_name, 0) + 1

            lane = assign_lane(det["bbox"], self.lane_polygons)
            det["lane"] = lane
            if lane is not None:
                lane_counts[lane] += 1
                self.lane_totals[lane] += 1

        self.frame_trend.append((frame_index, vehicle_count))

        overall_density = classify_density(vehicle_count)
        lane_densities = {lane: classify_density(cnt) for lane, cnt in lane_counts.items()}

        # Running (cumulative-average) signal per lane: this is the same
        # LOW->RED / else->GREEN rule applied to the average vehicle
        # count for that lane across every frame seen SO FAR, not just
        # this single frame. It converges to the final decision by the
        # last frame, but updating it every frame lets the output video
        # and the live camera feed both show it evolving in real time.
        # Each lane's signal is derived only from that lane's own running
        # average - no comparison against any other lane.
        lane_signals = {
            lane: build_lane_signal(self.lane_totals[lane] / self.frame_count)
            for lane in self.lane_names
        }

        return {
            "vehicle_count": vehicle_count,
            "lane_counts": lane_counts,
            "overall_density": overall_density,
            "lane_densities": lane_densities,
            "lane_signals": lane_signals,
        }

    def summary(self):
        avg_vehicles = (
            round(self.sum_vehicles_per_frame / self.frame_count, 2)
            if self.frame_count else 0
        )
        overall_density_label = classify_density(round(avg_vehicles))

        # Down-sample the trend so the embedded chart JSON stays small
        # even for long videos.
        trend = self.frame_trend
        if len(trend) > config.MAX_CHART_POINTS:
            step = len(trend) / config.MAX_CHART_POINTS
            sampled_idx = [int(i * step) for i in range(config.MAX_CHART_POINTS)]
            trend = [trend[i] for i in sampled_idx]

        road_utilization_pct = (
            round((self.sum_vehicles_per_frame / (self.frame_count * max(self.max_vehicles_in_frame, 1))) * 100, 1)
            if self.frame_count else 0
        )

        # --------------------------------------------------------
        # FINAL PER-LANE TRAFFIC SIGNAL
        # --------------------------------------------------------
        # Average that lane's vehicle count across every frame of the
        # whole video (e.g. 1000 frames -> lane_totals[lane] / 1000),
        # classify that average into LOW/MODERATE/HIGH/SEVERE, and turn
        # it into one final RED/GREEN recommendation per lane:
        #   LOW                    -> RED
        #   MODERATE/HIGH/SEVERE   -> GREEN
        # Every lane is computed independently from its own average -
        # lanes are never compared against each other and there is no
        # shared/winner signal state.
        final_signals = {
            lane: build_lane_signal(
                self.lane_totals[lane] / self.frame_count if self.frame_count else 0
            )
            for lane in self.lane_names
        }

        return {
            "total_frames": self.frame_count,
            "total_vehicle_detections": self.total_detections,
            "max_vehicles_in_frame": self.max_vehicles_in_frame,
            "average_vehicles_per_frame": avg_vehicles,
            "overall_density": overall_density_label,
            "class_totals": self.class_totals,
            "lane_totals": self.lane_totals,
            "lane_names": self.lane_names,
            "frame_trend": trend,
            "road_utilization_pct": road_utilization_pct,
            "final_signals": final_signals,
        }
