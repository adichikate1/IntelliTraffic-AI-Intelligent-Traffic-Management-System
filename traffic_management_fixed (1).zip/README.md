# AI Traffic Management System

A single-page Flask web app that runs an Ultralytics YOLOv8 ONNX model
(`model/best.onnx`) over an uploaded traffic video and produces an
annotated output video plus traffic-intelligence statistics: vehicle
counts, class breakdown, lane occupancy, and congestion classification.

The provided model detects 5 classes: **Bus, Car, Motorcycle, Pickup,
Truck** (read directly from the model's own embedded metadata — nothing
is hardcoded).

## Project structure

```
traffic_management/
├── app.py                 # Flask routes (no jsonify — server-rendered only)
├── config.py               # All thresholds / lane polygons / paths in one place
├── detector.py              # ONNX Runtime YOLOv8 preprocessing + inference + NMS
├── traffic_analysis.py      # Lane assignment, density classification, stats tracker
├── video_processor.py       # Frame-by-frame OpenCV pipeline + overlay drawing
├── requirements.txt
├── model/
│   └── best.onnx            # your model (already included)
├── uploads/                 # uploaded videos land here
├── outputs/                 # processed videos land here
├── templates/
│   └── index.html           # the one and only page
└── static/
    ├── css/style.css
    └── js/script.js         # drag-and-drop, loading overlay, vanilla-canvas chart
```

## Setup

```bash
cd traffic_management
python -m venv venv
venv\Scripts\activate        # Windows
# source venv/bin/activate   # macOS/Linux

pip install -r requirements.txt
```

> **GPU acceleration (optional):** the app auto-detects
> `CUDAExecutionProvider` and falls back to CPU automatically — it will
> never crash if CUDA isn't available. To enable GPU, install
> `onnxruntime-gpu` instead of `onnxruntime` (uninstall the CPU
> package first, since only one can be active) and make sure a
> compatible CUDA/cuDNN setup is on your machine.

## Run

```bash
python app.py
```

Open **http://127.0.0.1:5000/** in your browser.

## Using it

1. Drag a traffic video onto the upload zone (or click **Browse Video**).
   Supported formats: MP4, AVI, MOV, MKV (max 300 MB — change
   `MAX_CONTENT_LENGTH_MB` in `config.py` if you need more).
2. Click **Upload & Analyze**. Processing is synchronous — a loading
   overlay stays up until the annotated result is ready, then the same
   page re-renders with everything: original + processed video
   side-by-side, statistics, lane breakdown, vehicle-type counts, and a
   vehicle-count-over-time chart.
3. Click **Download Processed Video** to save the annotated MP4, or
   **New Analysis** to reset and upload another clip.

## Configuring lanes and thresholds

Open `config.py`:

- `LANE_POLYGONS` — lane regions as fractions of frame width/height
  (so they scale to any resolution). Defaults to a simple left-half /
  right-half split; edit the point lists to match your camera's actual
  lane geometry.
- `DENSITY_THRESHOLDS` — vehicle-count cutoffs for
  LOW / MODERATE / HIGH / SEVERE. Tune per scene.
- `CONFIDENCE_THRESHOLD` / `NMS_IOU_THRESHOLD` — detection filtering.
- `FALLBACK_CLASS_NAMES` — only used if a future model swap doesn't
  embed class names in its ONNX metadata.

No code changes are needed elsewhere to retune the system.

## Notes

- The model is loaded **once** at server startup (see the console for
  which execution provider — CUDA or CPU — is active), not per request
  or per frame.
- Video is streamed frame-by-frame with `cv2.VideoCapture` /
  `cv2.VideoWriter` — the full video is never loaded into memory.
- Output tries the browser-friendly `avc1` (H.264) codec first and
  falls back to `mp4v` automatically if H.264 isn't available in your
  OpenCV build — no FFmpeg install required either way.
- All uploaded/output filenames are UUID-prefixed and passed through
  `secure_filename()`; media routes only ever serve out of the
  `uploads/` and `outputs/` folders.
- No `jsonify()` and no JSON API routes anywhere — all data reaches
  the browser via Jinja template variables (see the `{{ }}` values and
  the one `| tojson` used to embed the chart's frame-trend array
  directly as a JS literal in `index.html`).
